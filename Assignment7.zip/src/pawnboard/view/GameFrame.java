package pawnboard.view;

import java.awt.BorderLayout;
import java.io.File;
import java.util.List;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import pawnboard.player.UserPlayer;
import pawnboard.controller.CardInitializer;
import pawnboard.model.PawnCard;
import pawnboard.model.PawnCell;
import pawnboard.model.PawnGameImpl;
import pawnboard.model.Player;
import pawnboard.model.ReadonlyPawnsGame;

/**
 * Represents a window frame for the game.
 * Contains panels for displaying the game board, the player's hand, and scores of
 * of both players. It sets up the overall layout and provides necessray functionality
 * to update the game view.
 * This abstract class is extended by specific implementationsfor each player.
 */
public abstract class GameFrame extends JFrame implements GameWindow {
  protected final ReadonlyPawnsGame<PawnCell, Player, PawnCard> model;
  protected final Player player;  // Each frame is associated with a specific player
  protected BoardPanel board;
  protected HandPanel hand;
  protected ScorePanel redScore;
  protected ScorePanel blueScore;
  private JButton quitButton;

  /**
   * Constructs a GameFrame for a specific player and game model.
   *
   * @param model  the model to observe
   * @param player the player associated with the game frame
   * @throws IllegalArgumentException if the model is null
   */
  public GameFrame(ReadonlyPawnsGame<PawnCell, Player, PawnCard> model, Player player) {
    super();
    if (model == null) {
      throw new IllegalArgumentException("model cannot be null");
    }

    this.model = model;
    this.player = player;
    setSize(1200, 600);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    redScore = new ScorePanel(model, Player.RED);
    hand = new HandPanel(model, player);
    board = new BoardPanel(model, hand);
    blueScore = new ScorePanel(model, Player.BLUE);

    this.add(redScore, BorderLayout.WEST);
    this.add(board, BorderLayout.CENTER);
    this.add(blueScore, BorderLayout.EAST);
    this.add(hand, BorderLayout.SOUTH);
    display();
  }

  /**
   * Allows to run the game frame.
   * @param args arguments
   */
  public static void main(String[] args) {
    String biggerPath = "docs" + File.separator + "biggerDeck";
    CardInitializer cardInitializer = new CardInitializer();
    Map<String, java.util.List<PawnCard>> decks =
            CardInitializer.initializeDeck(biggerPath, biggerPath);
    List<PawnCard> deck = decks.get("deck1");
    PawnGameImpl model = new PawnGameImpl(5, 7);
    model.startGame(deck, deck, 5);
    new RedFrame(model);
    new BlueFrame(model);

    model.placeCardAt(Player.RED, 0, 0,0);
  }

  @Override
  public void display() {
    setVisible(true);
  }

  @Override
  public void updateView() {
    repaint();
  }

  @Override
  public BoardPanel getBoardPanel() {
    return this.board;
  }

  @Override
  public HandPanel getHandPanel() {
    return this.hand;
  }


  @Override
  public void updateWindowTitle(Player currentPlayer, Player userPlayer) {
    if (currentPlayer.equals(userPlayer)) {
      this.setTitle(userPlayer + " - Your Turn");
    } else {
      this.setTitle(userPlayer + " - Waiting for Turn");
    }
    this.repaint();
  }

  @Override
  public void showTurnNotification(UserPlayer currentUserPlayer) {
    if (!currentUserPlayer.isMachine()) {
      JOptionPane.showMessageDialog(this, "It's " + currentUserPlayer.getPlayer()
              + "'s turn!", "Turn Notification", JOptionPane.INFORMATION_MESSAGE);
    }
  }

  @Override
  public void showOnGameOver(String winner, int redScore, int blueScore) {
    JOptionPane.showMessageDialog(null, "Game Over! The winner is: "
            + winner + "\nFinal Scores:\nRed: " + redScore + "\nBlue: " + blueScore, "Game Over",
            JOptionPane.INFORMATION_MESSAGE);
  }

  public void showInvalidMoveNotification(String message) {
    JOptionPane.showMessageDialog(this,
            "Invalid Move: " + message, "Move Error", JOptionPane.ERROR_MESSAGE);
  }

}

