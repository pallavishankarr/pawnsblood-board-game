package pawnboard.model;

import java.util.List;

import pawnboard.view.GameObserver;

/**
 * Represents a read-only version of the PawnsGame model.
 * It allows access to the board state and legal move checks without modifying the game state.
 * @param <C> the type of cells on the board
 * @param <P> the type of player
 * @param <T> the type of cards used in the game
 */
public interface ReadonlyPawnsGame<C extends Cell<P, T>, P extends Player, T extends Card> {

  /**
   * Retrieves the number of cells that make up the width of the board.
   * Number of cells in the largest row
   * @return the width of the board
   */
  int getWidth();

  /**
   * Retrieves the number of cells that make up the height of the board.
   * Number of rows in the highest column
   * @return the height of the board
   */
  int getHeight();

  /**
   * Determines if the placing card with a given card is legal.
   * @param player the player placing the card
   * @param card the card being placed
   * @param row row of where card should be placed (0-index based)
   * @param col col of where card should be placed (0-index based)
   * @return boolean based on if not placing card is legal
   * @throws IllegalStateException if the game hasn't started
   */
  boolean placeCardLegal(P player, T card, int row, int col) ;

  /**
   * Returns a deep copy of the current board state.
   * @throws IllegalStateException if the game has not started
   * @return a deep copy of the board, preserving the current game state
   */
  C[][] getBoard();

  /**
   * Returns the cell at the indicated position on the board.
   * @param row the row to access (0-index based)
   * @param col the column to access (0-index based)
   * @return the cell in the valid position
   * @throws IllegalArgumentException if the row and column are not a valid location
   *                                  for a Cell on the board
   */
  C getCellAt(int row, int col);

  /**
   * Gets the current player.
   * @return The player whose turn it is
   * @throws IllegalStateException if the game has not started
   */
  Player getCurrentPlayer();

  /**
   * Returns a copy of the given player's current hand. If their hand is empty, then an empty
   * list is returned.
   * @return a copy of the player's current hand
   * @throws IllegalStateException if the game has not started
   */
  List<PawnCard> getHand(P player);

  /**
   * Returns the number of cards left in a player's deck.
   * @param player the player whose deck needs to be accessed
   * @return the number of cards left in the players deck.
   * @throws IllegalStateException if the game has not started
   */
  int getRemainingDeckSize(P player);

  /**
   * Gets the winner of the game.
   * @return the player who won
   * @throws IllegalStateException if the game has not started
   */
  String getWinner();

  /**
   * Checks and returns the score of the Player.
   * @param player checks the score of the player
   * @return the integer of the Score
   * @throws IllegalStateException if the game has not started
   */
  int checkScore(P player);

  /**
   * Checks the Score of the row based on the Player.
   * @param player player that score is being checked
   * @param rowIdx the row index that is being checked (0-index based)
   * @return the score of the
   * @throws IllegalArgumentException if the rowIdx is out of row bounds
   */
  int checkScoreRow(P player, int rowIdx);

  /**
   * Determines if the game has ended.
   * @return true if the game is over, false if the game is not over
   * @throws IllegalStateException if the game has not started
   */
  boolean isGameOver();

  /**
   * Determines which Player owns the cell at a given coordinate.
   * @param row row number of the index (0-index based)
   * @param col column number of the index (0-index based)
   * @return Player which owns the cell
   * @throws IllegalStateException if the game has not started
   */
  Player getOwnerAt(int row, int col);

  /**
   * Adds an observer to the game.
   * The observer will be notified of game state changes.
   * If the observer is already added, it will not be added again.
   *
   * @param observer the observer to be added
   * @throws IllegalArgumentException if the observer is null
   */
  void addObserver(GameObserver observer);


  /**
   * Removes an observer from the game.
   * If the observer is not present, no action is taken.
   *
   * @param observer the observer to be removed
   * @throws IllegalArgumentException if the observer is null
   */
  void removeObserver(GameObserver observer);
}
